# Minecraft Shop Bot

Bot Discord per la gestione di uno shop di server Minecraft gratuiti.

## Funzionalità

### Sistema Ticket
- Apertura ticket automatica con categoria dedicata
- Chiusura ticket con comando o pulsante
- Tracking in database

### Sistema Ordini
- Menù interattivo per selezione tipo server
- Form modale per dettagli ordine
- Tracking stato ordini (pending, processing, completed, cancelled)
- Notifiche automatiche agli utenti

### Sistema Recensioni
- Valutazione con stelle (1-5)
- Controllo recensioni duplicate
- Calcolo media automatica
- Pubblicazione in canale dedicato

### Comandi Admin
- Aggiornamento stato ordini
- Statistiche complete
- Annunci formattati
- Gestione ordini in attesa

## Installazione

1. Installa Python 3.8 o superiore
2. Installa le dipendenze:
```bash
pip install -r requirements.txt
```

3. Configura il file .env con il tuo token Discord:
```
DISCORD_TOKEN=il_tuo_token_qui
```

4. Avvia il bot:
```bash
python bot.py
```

## Configurazione

Modifica `config.json` per personalizzare:
- ID ruoli staff
- ID canali specifici
- Colori embed
- Tipi di ordini disponibili

## Database

Il bot usa SQLite per salvare:
- Ticket (id, user_id, channel_id, timestamps, status)
- Ordini (id, user_id, tipo, dettagli, status, timestamps)
- Recensioni (id, user_id, rating, testo, timestamp)

## Comandi Disponibili

**Utenti:**
- `!ticket` - Apri un ticket di supporto
- `!order` - Crea un nuovo ordine
- `!myorders` - Visualizza i tuoi ordini
- `!orderstatus <id>` - Controlla stato ordine
- `!review <voto> <testo>` - Lascia una recensione
- `!reviews` - Visualizza recensioni
- `!help` - Lista comandi

**Staff:**
- `!close` - Chiudi ticket corrente
- `!setorder <id> <status>` - Aggiorna stato ordine
- `!stats` - Statistiche complete
- `!announce <messaggio>` - Invia annuncio
- `!deleteorder <id>` - Elimina ordine
- `!pendingorders` - Visualizza ordini in attesa

## Note

- Assicurati che il bot abbia i permessi necessari (gestione canali, ruoli, messaggi)
- Crea un ruolo "Staff" per i comandi admin
- Il database viene creato automaticamente al primo avvio