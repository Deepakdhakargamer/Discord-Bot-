import discord
from discord.ext import commands
import json
import sqlite3
from datetime import datetime

class OrderSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Server Vanilla", description="Server Minecraft Vanilla base", emoji="🌱"),
            discord.SelectOption(label="Server Modded", description="Server con mod installate", emoji="🔧"),
            discord.SelectOption(label="Server Plugin", description="Server con plugin Spigot/Paper", emoji="🔌"),
            discord.SelectOption(label="Server Network", description="Network multi-server con BungeeCord", emoji="🌐"),
            discord.SelectOption(label="Configurazione Custom", description="Server personalizzato", emoji="⚙️")
        ]
        super().__init__(placeholder="Seleziona il tipo di server...", options=options)
    
    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(OrderModal(self.values[0]))

class OrderView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)
        self.add_item(OrderSelect())

class OrderModal(discord.ui.Modal):
    def __init__(self, order_type):
        super().__init__(title=f"Ordine: {order_type}")
        self.order_type = order_type
        
        self.server_name = discord.ui.TextInput(
            label="Nome del Server",
            placeholder="Es: Il mio server Survival",
            required=True,
            max_length=50
        )
        
        self.description = discord.ui.TextInput(
            label="Descrizione",
            placeholder="Descrivi cosa vuoi per il tuo server...",
            style=discord.TextStyle.paragraph,
            required=True,
            max_length=500
        )
        
        self.players = discord.ui.TextInput(
            label="Numero Giocatori Stimato",
            placeholder="Es: 20-50",
            required=True,
            max_length=10
        )
        
        self.add_item(self.server_name)
        self.add_item(self.description)
        self.add_item(self.players)
    
    async def on_submit(self, interaction: discord.Interaction):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute('''INSERT INTO orders (user_id, order_type, server_name, description, players, status, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?)''',
                  (interaction.user.id, self.order_type, self.server_name.value,
                   self.description.value, self.players.value, 'pending', datetime.now().isoformat()))
        order_id = c.lastrowid
        conn.commit()
        conn.close()
        
        embed = discord.Embed(
            title="✅ Ordine Creato!",
            description=f"Il tuo ordine è stato registrato con successo!",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="🆔 ID Ordine", value=f"`{order_id}`", inline=True)
        embed.add_field(name="📦 Tipo", value=self.order_type, inline=True)
        embed.add_field(name="📊 Stato", value="⏳ In Attesa", inline=True)
        embed.add_field(name="🏷️ Nome Server", value=self.server_name.value, inline=False)
        embed.add_field(name="👥 Giocatori", value=self.players.value, inline=False)
        embed.set_footer(text=f"Ordinato da {interaction.user.name}", icon_url=interaction.user.display_avatar.url)
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
        orders_channel = interaction.guild.get_channel(interaction.guild.text_channels[0].id)
        staff_embed = discord.Embed(
            title="🆕 Nuovo Ordine Ricevuto!",
            description=f"**Ordinato da:** {interaction.user.mention}\n**ID Ordine:** `{order_id}`",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        staff_embed.add_field(name="Tipo", value=self.order_type, inline=True)
        staff_embed.add_field(name="Nome Server", value=self.server_name.value, inline=True)
        staff_embed.add_field(name="Giocatori", value=self.players.value, inline=True)
        staff_embed.add_field(name="Descrizione", value=self.description.value, inline=False)
        
        try:
            await orders_channel.send(embed=staff_embed)
        except:
            pass

class Orders(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.setup_database()
    
    def setup_database(self):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS orders
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      user_id INTEGER,
                      order_type TEXT,
                      server_name TEXT,
                      description TEXT,
                      players TEXT,
                      status TEXT,
                      created_at TEXT,
                      completed_at TEXT)''')
        conn.commit()
        conn.close()
    
    @commands.command(name='order')
    async def create_order(self, ctx):
        embed = discord.Embed(
            title="📦 Crea un Ordine",
            description="Seleziona il tipo di server che desideri dal menù qui sotto:",
            color=discord.Color.blue()
        )
        embed.add_field(
            name="🌱 Server Vanilla",
            value="Server Minecraft base senza modifiche",
            inline=True
        )
        embed.add_field(
            name="🔧 Server Modded",
            value="Server con mod (Forge/Fabric)",
            inline=True
        )
        embed.add_field(
            name="🔌 Server Plugin",
            value="Server con plugin Spigot/Paper",
            inline=True
        )
        embed.add_field(
            name="🌐 Server Network",
            value="Network con più server collegati",
            inline=True
        )
        embed.add_field(
            name="⚙️ Custom",
            value="Configurazione personalizzata",
            inline=True
        )
        
        view = OrderView()
        await ctx.send(embed=embed, view=view)
    
    @commands.command(name='myorders')
    async def my_orders(self, ctx):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC", (ctx.author.id,))
        orders = c.fetchall()
        conn.close()
        
        if not orders:
            await ctx.send("❌ Non hai ancora effettuato ordini!")
            return
        
        embed = discord.Embed(
            title="📦 I Tuoi Ordini",
            description=f"Hai effettuato {len(orders)} ordini",
            color=discord.Color.blue()
        )
        
        status_emoji = {
            'pending': '⏳',
            'processing': '🔄',
            'completed': '✅',
            'cancelled': '❌'
        }
        
        for order in orders[:10]:
            order_id, user_id, order_type, server_name, desc, players, status, created, completed = order
            emoji = status_emoji.get(status, '❓')
            embed.add_field(
                name=f"{emoji} Ordine #{order_id} - {server_name}",
                value=f"**Tipo:** {order_type}\n**Stato:** {status}\n**Data:** {created[:10]}",
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='orderstatus')
    async def order_status(self, ctx, order_id: int):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
        order = c.fetchone()
        conn.close()
        
        if not order:
            await ctx.send("❌ Ordine non trovato!")
            return
        
        order_id, user_id, order_type, server_name, desc, players, status, created, completed = order
        
        status_info = {
            'pending': ('⏳ In Attesa', 'Il tuo ordine è in coda', discord.Color.orange()),
            'processing': ('🔄 In Elaborazione', 'Stiamo lavorando al tuo server!', discord.Color.blue()),
            'completed': ('✅ Completato', 'Il tuo server è pronto!', discord.Color.green()),
            'cancelled': ('❌ Annullato', 'L\'ordine è stato annullato', discord.Color.red())
        }
        
        status_text, status_desc, color = status_info.get(status, ('❓ Sconosciuto', 'Stato non riconosciuto', discord.Color.greyple()))
        
        embed = discord.Embed(
            title=f"📋 Stato Ordine #{order_id}",
            description=status_desc,
            color=color,
            timestamp=datetime.now()
        )
        embed.add_field(name="🏷️ Nome Server", value=server_name, inline=True)
        embed.add_field(name="📦 Tipo", value=order_type, inline=True)
        embed.add_field(name="📊 Stato", value=status_text, inline=True)
        embed.add_field(name="📝 Descrizione", value=desc, inline=False)
        embed.add_field(name="👥 Giocatori", value=players, inline=True)
        embed.add_field(name="📅 Creato il", value=created[:10], inline=True)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Orders(bot))