import discord
from discord.ext import commands
import sqlite3
from datetime import datetime

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    def is_staff(ctx):
        return any(role.name.lower() in ['staff', 'admin', 'moderator', 'mod'] for role in ctx.author.roles)
    
    @commands.command(name='setorder')
    @commands.check(is_staff)
    async def set_order_status(self, ctx, order_id: int, status: str):
        valid_statuses = ['pending', 'processing', 'completed', 'cancelled']
        
        if status.lower() not in valid_statuses:
            await ctx.send(f"❌ Stato non valido! Usa uno tra: {', '.join(valid_statuses)}")
            return
        
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
        order = c.fetchone()
        
        if not order:
            await ctx.send("❌ Ordine non trovato!")
            conn.close()
            return
        
        old_status = order[6]
        
        if status.lower() == 'completed':
            c.execute("UPDATE orders SET status = ?, completed_at = ? WHERE id = ?",
                     (status.lower(), datetime.now().isoformat(), order_id))
        else:
            c.execute("UPDATE orders SET status = ? WHERE id = ?", (status.lower(), order_id))
        
        conn.commit()
        conn.close()
        
        status_emoji = {
            'pending': '⏳',
            'processing': '🔄',
            'completed': '✅',
            'cancelled': '❌'
        }
        
        embed = discord.Embed(
            title="✅ Stato Ordine Aggiornato",
            description=f"Ordine #{order_id} aggiornato con successo!",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Stato Precedente", value=f"{status_emoji.get(old_status, '❓')} {old_status}", inline=True)
        embed.add_field(name="Nuovo Stato", value=f"{status_emoji.get(status.lower(), '❓')} {status.lower()}", inline=True)
        
        await ctx.send(embed=embed)
        
        user_id = order[1]
        try:
            user = await self.bot.fetch_user(user_id)
            
            user_embed = discord.Embed(
                title=f"📦 Aggiornamento Ordine #{order_id}",
                description=f"Il tuo ordine è stato aggiornato!",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            user_embed.add_field(name="Nuovo Stato", value=f"{status_emoji.get(status.lower(), '❓')} {status.lower()}", inline=False)
            
            if status.lower() == 'completed':
                user_embed.add_field(name="🎉 Completato!", value="Il tuo server è pronto! Controlla i tuoi messaggi privati per i dettagli.", inline=False)
                
                rewards_cog = self.bot.get_cog('Rewards')
                if rewards_cog:
                    order_type = order[2]
                    new_points, new_level = await rewards_cog.on_order_completed(user_id, order_type)
                    user_embed.add_field(name="💎 Punti Guadagnati!", value=f"Hai guadagnato punti per questo ordine!\nTotale punti: {new_points}", inline=False)
            
            await user.send(embed=user_embed)
        except:
            pass
    
    @commands.command(name='stats')
    @commands.check(is_staff)
    async def show_stats(self, ctx):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM orders")
        total_orders = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM orders WHERE status = 'completed'")
        completed_orders = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM orders WHERE status = 'pending'")
        pending_orders = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM orders WHERE status = 'processing'")
        processing_orders = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM reviews")
        total_reviews = c.fetchone()[0]
        
        c.execute("SELECT AVG(rating) FROM reviews")
        avg_rating = c.fetchone()[0] or 0
        
        c.execute("SELECT COUNT(DISTINCT user_id) FROM orders")
        unique_customers = c.fetchone()[0]
        
        c.execute("SELECT SUM(points) FROM user_points")
        total_points = c.fetchone()[0] or 0
        
        c.execute("SELECT COUNT(*) FROM reward_claims")
        total_claims = c.fetchone()[0]
        
        conn.close()
        
        embed = discord.Embed(
            title="📊 Statistiche Server",
            description="Panoramica completa del server",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        embed.add_field(name="📦 Ordini Totali", value=str(total_orders), inline=True)
        embed.add_field(name="✅ Completati", value=str(completed_orders), inline=True)
        embed.add_field(name="⏳ In Attesa", value=str(pending_orders), inline=True)
        embed.add_field(name="🔄 In Elaborazione", value=str(processing_orders), inline=True)
        embed.add_field(name="👥 Clienti Unici", value=str(unique_customers), inline=True)
        embed.add_field(name="⭐ Recensioni", value=str(total_reviews), inline=True)
        embed.add_field(name="📈 Media Voti", value=f"{avg_rating:.1f}/5.0", inline=True)
        embed.add_field(name="💎 Punti Totali", value=str(total_points), inline=True)
        embed.add_field(name="🎁 Ricompense Riscattate", value=str(total_claims), inline=True)
        
        embed.set_footer(text=f"Richiesto da {ctx.author.name}", icon_url=ctx.author.display_avatar.url)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='announce')
    @commands.check(is_staff)
    async def announce(self, ctx, *, message: str):
        embed = discord.Embed(
            title="📢 Annuncio",
            description=message,
            color=discord.Color.gold(),
            timestamp=datetime.now()
        )
        embed.set_footer(text=f"Annuncio da {ctx.author.name}", icon_url=ctx.author.display_avatar.url)
        
        announcement_channel = None
        for channel in ctx.guild.text_channels:
            if 'annunci' in channel.name.lower() or 'announcements' in channel.name.lower():
                announcement_channel = channel
                break
        
        if announcement_channel:
            await announcement_channel.send(embed=embed)
            await ctx.send(f"✅ Annuncio inviato in {announcement_channel.mention}")
        else:
            await ctx.send(embed=embed)
            await ctx.send("✅ Annuncio inviato in questo canale (nessun canale annunci trovato)")
    
    @commands.command(name='addpoints')
    @commands.check(is_staff)
    async def add_points_manual(self, ctx, member: discord.Member, points: int, *, reason: str = "Assegnazione manuale"):
        rewards_cog = self.bot.get_cog('Rewards')
        if not rewards_cog:
            await ctx.send("❌ Sistema ricompense non disponibile!")
            return
        
        new_points, new_level = rewards_cog.add_points(member.id, points, reason)
        
        embed = discord.Embed(
            title="✅ Punti Assegnati",
            description=f"Hai assegnato **{points}** punti a {member.mention}",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="💎 Punti Totali", value=str(new_points), inline=True)
        embed.add_field(name="📊 Livello", value=rewards_cog.get_level_name(new_level), inline=True)
        embed.add_field(name="📝 Motivo", value=reason, inline=False)
        
        await ctx.send(embed=embed)
        
        try:
            user_embed = discord.Embed(
                title="🎁 Hai Ricevuto Punti!",
                description=f"Hai ricevuto **{points}** punti!",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            user_embed.add_field(name="💎 Punti Totali", value=str(new_points), inline=True)
            user_embed.add_field(name="📊 Livello", value=rewards_cog.get_level_name(new_level), inline=True)
            user_embed.add_field(name="📝 Motivo", value=reason, inline=False)
            
            await member.send(embed=user_embed)
        except:
            pass
    
    @commands.command(name='removepoints')
    @commands.check(is_staff)
    async def remove_points_manual(self, ctx, member: discord.Member, points: int, *, reason: str = "Rimozione manuale"):
        rewards_cog = self.bot.get_cog('Rewards')
        if not rewards_cog:
            await ctx.send("❌ Sistema ricompense non disponibile!")
            return
        
        new_points, new_level = rewards_cog.add_points(member.id, -points, reason)
        
        embed = discord.Embed(
            title="✅ Punti Rimossi",
            description=f"Hai rimosso **{points}** punti a {member.mention}",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        embed.add_field(name="💎 Punti Rimanenti", value=str(new_points), inline=True)
        embed.add_field(name="📊 Livello", value=rewards_cog.get_level_name(new_level), inline=True)
        embed.add_field(name="📝 Motivo", value=reason, inline=False)
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Admin(bot))