import discord
from discord.ext import commands
import sqlite3
from datetime import datetime

class Reviews(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.setup_database()
    
    def setup_database(self):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS reviews
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      user_id INTEGER,
                      rating INTEGER,
                      review_text TEXT,
                      created_at TEXT)''')
        conn.commit()
        conn.close()
    
    @commands.command(name='review')
    async def add_review(self, ctx, rating: int, *, review_text: str):
        if rating < 1 or rating > 5:
            await ctx.send("❌ Il voto deve essere tra 1 e 5 stelle!")
            return
        
        if len(review_text) < 10:
            await ctx.send("❌ La recensione deve essere di almeno 10 caratteri!")
            return
        
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("SELECT * FROM reviews WHERE user_id = ?", (ctx.author.id,))
        existing = c.fetchone()
        
        if existing:
            await ctx.send("❌ Hai già lasciato una recensione! Contatta lo staff per modificarla.")
            conn.close()
            return
        
        c.execute("INSERT INTO reviews (user_id, rating, review_text, created_at) VALUES (?, ?, ?, ?)",
                  (ctx.author.id, rating, review_text, datetime.now().isoformat()))
        review_id = c.lastrowid
        conn.commit()
        conn.close()
        
        rewards_cog = self.bot.get_cog('Rewards')
        if rewards_cog:
            new_points, new_level = await rewards_cog.on_review_submitted(ctx.author.id, rating)
            points_msg = f"\n\n💎 Hai guadagnato punti per questa recensione! Totale: {new_points}"
        else:
            points_msg = ""
        
        stars = "⭐" * rating
        
        embed = discord.Embed(
            title="✅ Recensione Inviata!",
            description=f"Grazie per il tuo feedback!{points_msg}",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Valutazione", value=stars, inline=False)
        embed.add_field(name="Recensione", value=review_text, inline=False)
        embed.set_footer(text=f"Recensione #{review_id}")
        
        await ctx.send(embed=embed)
        
        reviews_channel = None
        for channel in ctx.guild.text_channels:
            if 'recensioni' in channel.name.lower() or 'reviews' in channel.name.lower():
                reviews_channel = channel
                break
        
        if reviews_channel:
            public_embed = discord.Embed(
                title=f"{stars} Nuova Recensione!",
                description=review_text,
                color=discord.Color.gold(),
                timestamp=datetime.now()
            )
            public_embed.set_author(name=ctx.author.name, icon_url=ctx.author.display_avatar.url)
            public_embed.set_footer(text=f"Recensione #{review_id}")
            await reviews_channel.send(embed=public_embed)
    
    @commands.command(name='reviews')
    async def show_reviews(self, ctx):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("SELECT * FROM reviews ORDER BY created_at DESC LIMIT 10")
        reviews = c.fetchall()
        
        c.execute("SELECT AVG(rating), COUNT(*) FROM reviews")
        avg_rating, total = c.fetchone()
        conn.close()
        
        if not reviews:
            await ctx.send("❌ Nessuna recensione ancora disponibile!")
            return
        
        avg_stars = "⭐" * round(avg_rating) if avg_rating else "Nessuna"
        
        embed = discord.Embed(
            title="⭐ Recensioni Clienti",
            description=f"**Media:** {avg_stars} ({avg_rating:.1f}/5)\n**Totale recensioni:** {total}",
            color=discord.Color.gold()
        )
        
        for review in reviews:
            review_id, user_id, rating, text, created = review
            user = await self.bot.fetch_user(user_id)
            stars = "⭐" * rating
            embed.add_field(
                name=f"{stars} - {user.name}",
                value=f"{text[:100]}{'...' if len(text) > 100 else ''}\n*{created[:10]}*",
                inline=False
            )
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Reviews(bot))