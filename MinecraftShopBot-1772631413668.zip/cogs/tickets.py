import discord
from discord.ext import commands
from discord import app_commands
import json
import sqlite3
from datetime import datetime

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Chiudi Ticket", style=discord.ButtonStyle.danger, custom_id="close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if discord.utils.get(interaction.user.roles, name="Staff") or interaction.channel.permissions_for(interaction.user).manage_channels:
            embed = discord.Embed(
                title="🔒 Ticket Chiuso",
                description=f"Ticket chiuso da {interaction.user.mention}",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            await interaction.response.send_message(embed=embed)
            await interaction.channel.send("Questo canale verrà eliminato in 5 secondi...")
            await discord.utils.sleep_until(discord.utils.utcnow() + discord.timedelta(seconds=5))
            await interaction.channel.delete()
        else:
            await interaction.response.send_message("❌ Solo lo staff può chiudere i ticket!", ephemeral=True)

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.setup_database()
    
    def setup_database(self):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS tickets
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      user_id INTEGER,
                      channel_id INTEGER,
                      created_at TEXT,
                      closed_at TEXT,
                      status TEXT)''')
        conn.commit()
        conn.close()
    
    @commands.command(name='ticket')
    async def create_ticket(self, ctx):
        guild = ctx.guild
        user = ctx.author
        
        category = discord.utils.get(guild.categories, name="TICKETS")
        if not category:
            category = await guild.create_category("TICKETS")
        
        ticket_channel = await guild.create_text_channel(
            f'ticket-{user.name}',
            category=category,
            topic=f'Ticket di {user.name} - {user.id}'
        )
        
        await ticket_channel.set_permissions(guild.default_role, read_messages=False)
        await ticket_channel.set_permissions(user, read_messages=True, send_messages=True)
        
        staff_role = discord.utils.get(guild.roles, name="Staff")
        if staff_role:
            await ticket_channel.set_permissions(staff_role, read_messages=True, send_messages=True)
        
        embed = discord.Embed(
            title="🎫 Nuovo Ticket",
            description=f"Benvenuto {user.mention}!\n\nGrazie per aver aperto un ticket. Un membro dello staff ti risponderà a breve.\n\nDescrivi il tuo problema o la tua richiesta in dettaglio.",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="📌 Info", value="Per chiudere il ticket, lo staff userà il pulsante qui sotto.", inline=False)
        embed.set_footer(text=f"Ticket aperto da {user.name}", icon_url=user.display_avatar.url)
        
        view = TicketView()
        await ticket_channel.send(f"{user.mention}", embed=embed, view=view)
        
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("INSERT INTO tickets (user_id, channel_id, created_at, status) VALUES (?, ?, ?, ?)",
                  (user.id, ticket_channel.id, datetime.now().isoformat(), 'open'))
        conn.commit()
        conn.close()
        
        await ctx.send(f"✅ Ticket creato! {ticket_channel.mention}", delete_after=10)
    
    @commands.command(name='close')
    @commands.has_permissions(manage_channels=True)
    async def close_ticket(self, ctx):
        if ctx.channel.name.startswith('ticket-'):
            embed = discord.Embed(
                title="🔒 Ticket Chiuso",
                description=f"Ticket chiuso da {ctx.author.mention}",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            await ctx.send(embed=embed)
            
            conn = sqlite3.connect('shop.db')
            c = conn.cursor()
            c.execute("UPDATE tickets SET closed_at = ?, status = ? WHERE channel_id = ?",
                      (datetime.now().isoformat(), 'closed', ctx.channel.id))
            conn.commit()
            conn.close()
            
            await ctx.send("Questo canale verrà eliminato in 5 secondi...")
            await discord.utils.sleep_until(discord.utils.utcnow() + discord.timedelta(seconds=5))
            await ctx.channel.delete()
        else:
            await ctx.send("❌ Questo comando può essere usato solo nei canali ticket!")

async def setup(bot):
    await bot.add_cog(Tickets(bot))