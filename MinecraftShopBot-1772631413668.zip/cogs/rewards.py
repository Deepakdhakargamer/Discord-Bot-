import discord
from discord.ext import commands
import sqlite3
from datetime import datetime

class RewardSelect(discord.ui.Select):
    def __init__(self, user_points, rewards):
        options = []
        for reward in rewards:
            reward_id, name, description, cost, reward_type, available = reward
            if available:
                emoji = "🎁" if reward_type == "bonus" else "⭐" if reward_type == "upgrade" else "🏆"
                can_afford = user_points >= cost
                label = f"{name} ({cost} punti)"
                options.append(
                    discord.SelectOption(
                        label=label[:100],
                        description=description[:100],
                        emoji=emoji,
                        value=str(reward_id)
                    )
                )
        
        if not options:
            options.append(discord.SelectOption(label="Nessuna ricompensa disponibile", value="none"))
        
        super().__init__(placeholder="Seleziona una ricompensa da riscattare...", options=options)
        self.user_points = user_points
    
    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == "none":
            await interaction.response.send_message("❌ Nessuna ricompensa disponibile!", ephemeral=True)
            return
        
        reward_id = int(self.values[0])
        
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute("SELECT * FROM rewards WHERE id = ?", (reward_id,))
        reward = c.fetchone()
        
        if not reward:
            await interaction.response.send_message("❌ Ricompensa non trovata!", ephemeral=True)
            conn.close()
            return
        
        reward_id, name, description, cost, reward_type, available = reward
        
        c.execute("SELECT points FROM user_points WHERE user_id = ?", (interaction.user.id,))
        result = c.fetchone()
        current_points = result[0] if result else 0
        
        if current_points < cost:
            await interaction.response.send_message(f"❌ Non hai abbastanza punti! Ti servono {cost} punti ma ne hai solo {current_points}.", ephemeral=True)
            conn.close()
            return
        
        new_points = current_points - cost
        c.execute("UPDATE user_points SET points = ? WHERE user_id = ?", (new_points, interaction.user.id))
        
        c.execute('''INSERT INTO reward_claims (user_id, reward_id, claimed_at)
                     VALUES (?, ?, ?)''', (interaction.user.id, reward_id, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        embed = discord.Embed(
            title="🎉 Ricompensa Riscattata!",
            description=f"Hai riscattato con successo: **{name}**",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="💰 Costo", value=f"{cost} punti", inline=True)
        embed.add_field(name="📊 Punti Rimanenti", value=f"{new_points} punti", inline=True)
        embed.add_field(name="📝 Descrizione", value=description, inline=False)
        embed.set_footer(text="Contatta lo staff per ricevere la tua ricompensa!")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
        for channel in interaction.guild.text_channels:
            if 'staff' in channel.name.lower() or 'admin' in channel.name.lower():
                staff_embed = discord.Embed(
                    title="🎁 Nuova Ricompensa Riscattata",
                    description=f"{interaction.user.mention} ha riscattato una ricompensa!",
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                staff_embed.add_field(name="Ricompensa", value=name, inline=True)
                staff_embed.add_field(name="Utente", value=interaction.user.name, inline=True)
                staff_embed.add_field(name="Descrizione", value=description, inline=False)
                try:
                    await channel.send(embed=staff_embed)
                    break
                except:
                    pass

class RewardView(discord.ui.View):
    def __init__(self, user_points, rewards):
        super().__init__(timeout=60)
        self.add_item(RewardSelect(user_points, rewards))

class Rewards(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.setup_database()
        self.setup_default_rewards()
    
    def setup_database(self):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute('''CREATE TABLE IF NOT EXISTS user_points
                     (user_id INTEGER PRIMARY KEY,
                      points INTEGER DEFAULT 0,
                      level INTEGER DEFAULT 1,
                      total_earned INTEGER DEFAULT 0,
                      last_daily TEXT)''')
        
        c.execute('''CREATE TABLE IF NOT EXISTS rewards
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      name TEXT,
                      description TEXT,
                      cost INTEGER,
                      reward_type TEXT,
                      available INTEGER DEFAULT 1)''')
        
        c.execute('''CREATE TABLE IF NOT EXISTS reward_claims
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      user_id INTEGER,
                      reward_id INTEGER,
                      claimed_at TEXT)''')
        
        c.execute('''CREATE TABLE IF NOT EXISTS point_history
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      user_id INTEGER,
                      points INTEGER,
                      reason TEXT,
                      created_at TEXT)''')
        
        conn.commit()
        conn.close()
    
    def setup_default_rewards(self):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM rewards")
        if c.fetchone()[0] == 0:
            default_rewards = [
                ("Server Prioritario", "Il tuo ordine viene processato per primo", 100, "upgrade", 1),
                ("RAM Extra +2GB", "2GB di RAM aggiuntiva per il tuo server", 150, "upgrade", 1),
                ("Slot Extra +10", "10 slot giocatori aggiuntivi", 120, "upgrade", 1),
                ("Backup Settimanale", "Backup automatico settimanale per 1 mese", 200, "bonus", 1),
                ("Plugin Premium", "Un plugin premium a scelta installato", 250, "bonus", 1),
                ("Configurazione Custom", "Configurazione personalizzata completa", 300, "bonus", 1),
                ("Server VIP", "Server con risorse dedicate per 1 mese", 500, "upgrade", 1),
                ("Supporto Prioritario", "Supporto prioritario per 1 mese", 180, "bonus", 1),
                ("Dominio Gratuito", "Dominio personalizzato gratuito per 3 mesi", 400, "bonus", 1),
                ("Network Upgrade", "Upgrade a network multi-server", 600, "upgrade", 1)
            ]
            
            c.executemany("INSERT INTO rewards (name, description, cost, reward_type, available) VALUES (?, ?, ?, ?, ?)",
                         default_rewards)
            conn.commit()
        
        conn.close()
    
    def add_points(self, user_id, points, reason):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute("SELECT points, total_earned FROM user_points WHERE user_id = ?", (user_id,))
        result = c.fetchone()
        
        if result:
            current_points, total_earned = result
            new_points = current_points + points
            new_total = total_earned + points
            c.execute("UPDATE user_points SET points = ?, total_earned = ? WHERE user_id = ?",
                     (new_points, new_total, user_id))
        else:
            c.execute("INSERT INTO user_points (user_id, points, total_earned) VALUES (?, ?, ?)",
                     (user_id, points, points))
        
        c.execute("INSERT INTO point_history (user_id, points, reason, created_at) VALUES (?, ?, ?, ?)",
                 (user_id, points, reason, datetime.now().isoformat()))
        
        conn.commit()
        
        c.execute("SELECT points, total_earned FROM user_points WHERE user_id = ?", (user_id,))
        new_points, total_earned = c.fetchone()
        
        new_level = self.calculate_level(total_earned)
        c.execute("UPDATE user_points SET level = ? WHERE user_id = ?", (new_level, user_id))
        conn.commit()
        conn.close()
        
        return new_points, new_level
    
    def calculate_level(self, total_points):
        if total_points < 100:
            return 1
        elif total_points < 250:
            return 2
        elif total_points < 500:
            return 3
        elif total_points < 1000:
            return 4
        elif total_points < 2000:
            return 5
        elif total_points < 3500:
            return 6
        elif total_points < 5000:
            return 7
        elif total_points < 7500:
            return 8
        elif total_points < 10000:
            return 9
        else:
            return 10
    
    def get_level_name(self, level):
        level_names = {
            1: "🥉 Bronzo",
            2: "🥈 Argento",
            3: "🥇 Oro",
            4: "💎 Platino",
            5: "💠 Diamante",
            6: "🔷 Zaffiro",
            7: "🔶 Ambra",
            8: "⭐ Stella",
            9: "👑 Leggenda",
            10: "🏆 Maestro"
        }
        return level_names.get(level, "❓ Sconosciuto")
    
    @commands.command(name='points')
    async def show_points(self, ctx, member: discord.Member = None):
        target = member or ctx.author
        
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("SELECT points, level, total_earned FROM user_points WHERE user_id = ?", (target.id,))
        result = c.fetchone()
        
        if not result:
            if target == ctx.author:
                await ctx.send("❌ Non hai ancora guadagnato punti! Completa ordini e lascia recensioni per guadagnarne.")
            else:
                await ctx.send(f"❌ {target.name} non ha ancora guadagnato punti!")
            conn.close()
            return
        
        points, level, total_earned = result
        
        c.execute("SELECT COUNT(*) FROM reward_claims WHERE user_id = ?", (target.id,))
        claims_count = c.fetchone()[0]
        
        conn.close()
        
        level_name = self.get_level_name(level)
        next_level = level + 1 if level < 10 else 10
        next_level_points = [100, 250, 500, 1000, 2000, 3500, 5000, 7500, 10000, 999999][level - 1]
        progress = min(100, int((total_earned / next_level_points) * 100))
        
        embed = discord.Embed(
            title=f"💰 Punti di {target.name}",
            color=discord.Color.gold(),
            timestamp=datetime.now()
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="💎 Punti Attuali", value=f"**{points}** punti", inline=True)
        embed.add_field(name="📊 Livello", value=level_name, inline=True)
        embed.add_field(name="🏆 Totale Guadagnato", value=f"{total_earned} punti", inline=True)
        embed.add_field(name="🎁 Ricompense Riscattate", value=f"{claims_count} ricompense", inline=True)
        
        if level < 10:
            progress_bar = "█" * (progress // 10) + "░" * (10 - progress // 10)
            embed.add_field(
                name=f"📈 Progresso verso {self.get_level_name(next_level)}",
                value=f"{progress_bar} {progress}%\n{total_earned}/{next_level_points} punti",
                inline=False
            )
        
        embed.set_footer(text="Usa !rewards per vedere le ricompense disponibili")
        
        await ctx.send(embed=embed)
    
    @commands.command(name='rewards')
    async def show_rewards(self, ctx):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute("SELECT points FROM user_points WHERE user_id = ?", (ctx.author.id,))
        result = c.fetchone()
        user_points = result[0] if result else 0
        
        c.execute("SELECT * FROM rewards WHERE available = 1 ORDER BY cost ASC")
        rewards = c.fetchall()
        conn.close()
        
        if not rewards:
            await ctx.send("❌ Nessuna ricompensa disponibile al momento!")
            return
        
        embed = discord.Embed(
            title="🎁 Ricompense Disponibili",
            description=f"**I tuoi punti:** {user_points} 💎\n\nSeleziona una ricompensa dal menù qui sotto per riscattarla!",
            color=discord.Color.purple()
        )
        
        for reward in rewards:
            reward_id, name, description, cost, reward_type, available = reward
            emoji = "🎁" if reward_type == "bonus" else "⭐"
            can_afford = "✅" if user_points >= cost else "❌"
            embed.add_field(
                name=f"{emoji} {name} - {cost} punti {can_afford}",
                value=description,
                inline=False
            )
        
        embed.set_footer(text="Usa il menù qui sotto per riscattare una ricompensa")
        
        view = RewardView(user_points, rewards)
        await ctx.send(embed=embed, view=view)
    
    @commands.command(name='leaderboard')
    async def leaderboard(self, ctx):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("SELECT user_id, points, level, total_earned FROM user_points ORDER BY total_earned DESC LIMIT 10")
        top_users = c.fetchall()
        conn.close()
        
        if not top_users:
            await ctx.send("❌ Nessun utente in classifica ancora!")
            return
        
        embed = discord.Embed(
            title="🏆 Classifica Punti",
            description="I migliori 10 utenti per punti totali guadagnati",
            color=discord.Color.gold(),
            timestamp=datetime.now()
        )
        
        medals = ["🥇", "🥈", "🥉"]
        
        for idx, (user_id, points, level, total_earned) in enumerate(top_users):
            try:
                user = await self.bot.fetch_user(user_id)
                medal = medals[idx] if idx < 3 else f"#{idx + 1}"
                level_name = self.get_level_name(level)
                embed.add_field(
                    name=f"{medal} {user.name}",
                    value=f"{level_name}\n💎 {points} punti | 🏆 {total_earned} totali",
                    inline=False
                )
            except:
                pass
        
        await ctx.send(embed=embed)
    
    @commands.command(name='daily')
    async def daily_points(self, ctx):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        
        c.execute("SELECT last_daily FROM user_points WHERE user_id = ?", (ctx.author.id,))
        result = c.fetchone()
        
        if result and result[0]:
            last_daily = datetime.fromisoformat(result[0])
            time_diff = datetime.now() - last_daily
            
            if time_diff.total_seconds() < 86400:
                hours_left = int((86400 - time_diff.total_seconds()) / 3600)
                minutes_left = int(((86400 - time_diff.total_seconds()) % 3600) / 60)
                await ctx.send(f"⏰ Hai già riscattato i punti giornalieri! Torna tra {hours_left}h {minutes_left}m")
                conn.close()
                return
        
        daily_points = 10
        
        c.execute("SELECT level FROM user_points WHERE user_id = ?", (ctx.author.id,))
        level_result = c.fetchone()
        if level_result:
            bonus = level_result[0] * 2
            daily_points += bonus
        
        new_points, new_level = self.add_points(ctx.author.id, daily_points, "Ricompensa giornaliera")
        
        c.execute("UPDATE user_points SET last_daily = ? WHERE user_id = ?",
                 (datetime.now().isoformat(), ctx.author.id))
        conn.commit()
        conn.close()
        
        embed = discord.Embed(
            title="🎁 Ricompensa Giornaliera!",
            description=f"Hai ricevuto **{daily_points}** punti!",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="💎 Punti Totali", value=f"{new_points} punti", inline=True)
        embed.add_field(name="📊 Livello", value=self.get_level_name(new_level), inline=True)
        embed.set_footer(text="Torna domani per altri punti!")
        
        await ctx.send(embed=embed)
    
    @commands.command(name='history')
    async def point_history(self, ctx):
        conn = sqlite3.connect('shop.db')
        c = conn.cursor()
        c.execute("SELECT points, reason, created_at FROM point_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 15",
                 (ctx.author.id,))
        history = c.fetchall()
        conn.close()
        
        if not history:
            await ctx.send("❌ Nessuna cronologia punti disponibile!")
            return
        
        embed = discord.Embed(
            title="📜 Cronologia Punti",
            description="Le tue ultime 15 transazioni",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        
        for points, reason, created_at in history:
            emoji = "➕" if points > 0 else "➖"
            date = created_at[:10]
            embed.add_field(
                name=f"{emoji} {points:+d} punti",
                value=f"{reason}\n*{date}*",
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.Cog.listener()
    async def on_order_completed(self, user_id, order_type):
        points_map = {
            "Server Vanilla": 50,
            "Server Modded": 75,
            "Server Plugin": 75,
            "Server Network": 100,
            "Configurazione Custom": 60
        }
        
        points = points_map.get(order_type, 50)
        new_points, new_level = self.add_points(user_id, points, f"Ordine completato: {order_type}")
        
        return new_points, new_level
    
    @commands.Cog.listener()
    async def on_review_submitted(self, user_id, rating):
        base_points = 20
        bonus = (rating - 3) * 5 if rating > 3 else 0
        total_points = base_points + bonus
        
        new_points, new_level = self.add_points(user_id, total_points, f"Recensione lasciata ({rating} stelle)")
        
        return new_points, new_level

async def setup(bot):
    await bot.add_cog(Rewards(bot))